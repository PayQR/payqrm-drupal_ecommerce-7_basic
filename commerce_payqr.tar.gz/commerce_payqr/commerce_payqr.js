/**
 * Created by niko on 31.01.15.
 */
(function ($) {
  Drupal.behaviors.commerce_payqr = {
    attach: function (context, settings) {
      $('form.commerce-add-to-cart input[name="quantity"]', context).input(function () {
        var product_id = $('form.commerce-add-to-cart input[name="product_id"]', context).val();
        var quantity = $(this).val();
        var url = 'commerce_payqr/button_update/' + product_id + '/' + quantity;
        var payqr_button = $(this).parents('form.commerce-add-to-cart').find('button.payqr-button');
        $.get(url, function( data ) {
          var parsed_data = $.parseJSON(data);
          $.each(parsed_data, function(key, value){
            payqr_button.attr(key, value);
          });
        });
      });
    }
  };


})(jQuery);

