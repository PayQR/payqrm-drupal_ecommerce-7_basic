<?php
/**
 * Проверка валидности уведомлений и ответов от PayQR (проверка секретных ключей)
 */
 
class payqr_authentication
{

  /**
   * Проверяем header уведомлений и ответов от PayQR на соответствие значению SecretKeyIn
   *
   * @param $secretKeyIn
   * @return bool
   */
  public static function checkHeader($secretKeyIn, $headers=false)
  {
    if(!payqr_config::$checkHeader)
      return true;
    if(!$headers)
      $headers = getallheaders();
    if (!$headers) {
      header("HTTP/1.0 404 Not Found");
      payqr_logs::log("Отсутствует ['PQRSecretKey']");
      return false;
    }
    // Проверяем соответствие пришедшего значения поля PQRSecretKey значению SecretKeyIn из конфигурации библиотеки
    if (isset($headers['PQRSecretKey']) && $headers['PQRSecretKey'] == $secretKeyIn) {
      return true;
    }
    header("HTTP/1.0 404 Not Found");
    payqr_logs::log("Неверный ['PQRSecretKey']");
    return false;
  }

} 