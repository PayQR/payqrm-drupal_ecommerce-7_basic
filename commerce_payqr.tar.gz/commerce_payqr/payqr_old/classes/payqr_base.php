<?php
/**
 * Проверка конфигурации библиотеки PayQR
 */

class payqr_base {

  public static $apiUrl = "https://payqr.ru/shop/api/1.0"; // Не меняйте этот адрес без получения официальных извещений PayQR

  public static function checkConfig(){
    if(payqr_config::$secretKeyIn == "")
      throw new payqr_exeption("Поле payqr_config::secretKeyIn не может быть пустым, проверьте конфигурацию библиотеки PayQR");
    if(payqr_config::$secretKeyOut == "")
      throw new payqr_exeption("Поле payqr_config::secretKeyOut не может быть пустым, проверьте конфигурацию библиотеки PayQR");
    if(payqr_config::$enabledLog && payqr_config::$logFile == "")
      throw new payqr_exeption("Поле payqr_config::logFile не может быть пустым, проверьте конфигурацию библиотеки PayQR");
  }
} 