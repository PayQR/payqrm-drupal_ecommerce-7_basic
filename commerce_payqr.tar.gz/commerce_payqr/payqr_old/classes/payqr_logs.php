<?php
/**
 * Ведение отладочных логов
 */
 
class payqr_logs
{

  /**
   * Добавление записи в лог файл
   *
   * @param $file
   * @param $message
   */
  public static function log($message)
  {
    if(!payqr_config::$enabledLog)
      return;
    file_put_contents(payqr_config::$logFile, "\n==============" . date("Y-m-d h:i:s", time(1)) . "==============\n", FILE_APPEND);
    file_put_contents(payqr_config::$logFile, $message, FILE_APPEND);
    file_put_contents(payqr_config::$logFile, "\n============================\n", FILE_APPEND);
  }
} 